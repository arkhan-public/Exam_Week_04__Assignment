﻿using Microsoft.AspNetCore.Mvc;
using ToDoList.Models;

[Route("api/[controller]")]
[ApiController]
public class ToDoController : ControllerBase
{
    private static readonly List<ToDoItem> _listToDo = new();
    private static int _nextId = 1;

    static ToDoController()
    {
        // Initialize with dummy data
        _listToDo.Add(new ToDoItem(_nextId++, "Buy groceries", false));
        _listToDo.Add(new ToDoItem(_nextId++, "Finish API project", true));
    }

    [HttpGet]
    public ActionResult<IEnumerable<ToDoItem>> GetAll()
    {
        return Ok(_listToDo.OrderBy(t => t.Id));
    }

    [HttpGet("{id}")]
    public ActionResult<ToDoItem> GetById(int id)
    {
        var getItemToDo = _listToDo.FirstOrDefault(t => t.Id == id);
        return getItemToDo != null ? Ok(getItemToDo) : NotFound($"ToDo item with given ID ({id}) not found.");
    }

    [HttpPost]
    public ActionResult<ToDoItem> Create(ToDoItem newToDoItem)
    {
        if (string.IsNullOrWhiteSpace(newToDoItem.Title))
            return BadRequest("ToDo Title cannot be empty.");

        // Ignoring ID and Task Status
        var addToDoItem = newToDoItem with { Id = _nextId++, IsComplete = false };
        _listToDo.Add(addToDoItem);

        return CreatedAtAction(nameof(GetById), new { id = addToDoItem.Id }, addToDoItem);
    }

    [HttpPut("{id}")]
    public IActionResult Update(int id, ToDoItem newToDoItem)
    {
        if (string.IsNullOrWhiteSpace(newToDoItem.Title))
            return BadRequest("Updated ToDo Title cannot be empty.");

        var listIndex = _listToDo.FindIndex(t => t.Id == id);

        if (listIndex == -1)
            return NotFound($"ToDo item with given ID ({id}) not found for update.");

        var updatedToDoItem = newToDoItem with { Id = id };
        _listToDo[listIndex] = updatedToDoItem;

        return NoContent();
    }

    [HttpDelete("{id}")]
    public IActionResult Delete(int id)
    {
        var listIndex = _listToDo.FindIndex(t => t.Id == id);

        if (listIndex == -1)
            return NotFound($"ToDo item with given ID ({id}) not found for deletion.");

        _listToDo.RemoveAt(listIndex);

        return NoContent();
    }
}