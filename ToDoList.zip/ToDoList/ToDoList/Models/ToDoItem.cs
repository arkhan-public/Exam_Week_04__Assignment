﻿using Microsoft.AspNetCore.OpenApi;
using Microsoft.AspNetCore.Http.HttpResults;
namespace ToDoList.Models
{
    public record ToDoItem(int Id, string Title, bool IsComplete);
}